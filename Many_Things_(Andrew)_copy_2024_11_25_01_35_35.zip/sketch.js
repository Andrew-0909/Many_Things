let rectangle_train = []; // Creates train that holds rectangles 
const train_number = 11; // Tells the computer how many train seats we want to create.
let running = true;
function setup() {
  createCanvas(600, 400);
  // Initialize rectangles with random positions, sizes, colors, and directions
  
  
  // 여기서 rectangle 의 설계도를 제작함
  
  for (let i=0 ; i < 10; i++){
  let rectangle = {
    x: random(1,600),
    y: random (1,400),
    width: random (10,100),
    height: random (10, 50),
    xSpeed: random (-5,5),
    ySpeed: random (-5,5),
    color: color( random (1,255), random (1,255), random (1,255))
  };
    rectangle_train.push(rectangle);
  }
}

function draw() {
if(!running)return;
  background(220);
  
  // Changes in rectangle
  for ( let i=0; i < 10; i++) {
    let rectangle = rectangle_train[i]; 
    
    // Make the rectangles move!
    rectangle.x += rectangle.xSpeed;
    rectangle.y += rectangle.ySpeed;
    
    //Color Change
    let newRed = (red(rectangle.color)+2)%256;
    let newGreen = (green(rectangle.color)+2)%256;
    let newBlue = (blue(rectangle.color)+2)%256;
    
    rectangle.color = color(newRed, newGreen, newBlue );
    // Conditional statement 'if' to change direction when they are going over the boundaries
    if ( rectangle.x + rectangle.width > width || rectangle.x < 0) {
        rectangle.xSpeed *= -1;
        }
    
    if ( rectangle.y + rectangle.height > height || rectangle.y < 0) {
      rectangle.ySpeed *= -1;
    }
    
    fill (rectangle.color);
    rect (rectangle.x, rectangle.y, rectangle.width, rectangle.height);
    
    
    
  }
  
  

}


function mousePressed(){
  running = false;
}